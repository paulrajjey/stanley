package com.brms.client;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.drools.core.time.SessionPseudoClock;
import org.kie.api.KieServices;
import org.kie.api.builder.KieScanner;
import org.kie.api.builder.ReleaseId;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.event.rule.AgendaEventListener;
import org.kie.api.event.rule.AgendaGroupPoppedEvent;
import org.kie.api.event.rule.AgendaGroupPushedEvent;
import org.kie.api.event.rule.BeforeMatchFiredEvent;
import org.kie.api.event.rule.MatchCancelledEvent;
import org.kie.api.event.rule.MatchCreatedEvent;
import org.kie.api.event.rule.RuleFlowGroupActivatedEvent;
import org.kie.api.event.rule.RuleFlowGroupDeactivatedEvent;
import org.kie.api.logger.KieRuntimeLogger;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.cibc.event.GlobalServiceEvent;
import com.cibc.event.Trade;
import com.cibc.event.XtraderEvent;


public class CiBCEventRule {
	
	
	public KieContainer createContainer() {
    	System.out.println("kie container creation...");
    	
    	KieServices ks = KieServices.Factory.get();
    	
    	ReleaseId rId = ks.newReleaseId("redhat", "cepdemo", "1.4");
    	KieContainer kContainer = ks.newKieContainer(rId);
    	
    	
    	//KieScanner scanner =  ks.newKieScanner(kContainer);
    	//scanner.start(60000);
    	return kContainer;
    }
	
	public static void main(String[] ar){
		//CiBCEventRule notificaiton = new CiBCEventRule();
		KieServices ks = KieServices.Factory.get();
		
		ReleaseId rId = ks.newReleaseId("redhat", "cepdemo", "1.5");
    	KieContainer kContainer = ks.newKieContainer(rId);
		
		//KieContainer kContainer = notificaiton.createContainer();
		final KieSession kieSession = kContainer.newKieSession();
		KieRuntimeLogger logger;
    	logger = ks.getLoggers().newFileLogger(kieSession, "/Users/jpaulraj/scorecard");
    	kieSession.addEventListener(new AgendaEventListener() {
			
			public void matchCreated(MatchCreatedEvent event) {
				//System.out.println("Rule name  ::" + event.getMatch().getRule().getName());
				
			}
			
			
			public void matchCancelled(MatchCancelledEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void beforeRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeMatchFired(BeforeMatchFiredEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void agendaGroupPushed(AgendaGroupPushedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void agendaGroupPopped(AgendaGroupPoppedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterMatchFired(AfterMatchFiredEvent event) {
				System.out.println("afterMatchFired   ::" + event.getMatch().getRule().getName());
				
			}
		});
		//kieSession.fireUntilHalt();
		new Thread(new Runnable() {
		      public void run() {
		    	  kieSession.fireUntilHalt();
		      }
		        }).start();
		
		XtraderEvent eventA = new XtraderEvent();
		String Usi_trans_id = "1001";
		eventA.setUsi_trans_id(Usi_trans_id);
		eventA.setStruct_ref("1001R");
		
		String GlobeMessageID = "G1001";
		GlobalServiceEvent eventB = new GlobalServiceEvent();
		eventB.setGlobeMessageID(GlobeMessageID);
		eventB.setSourceSystemTransID(Usi_trans_id);
		
		/*Trade trade1 = new Trade();
		trade1.setGlobeMessageID(GlobeMessageID);
		trade1.setSourceSystemTradeID(Usi_trans_id);
		Trade trade2 = new Trade();
		trade2.setGlobeMessageID("1002");
		trade2.setSourceSystemTradeID(Usi_trans_id);
		List<Trade> trades = new ArrayList<Trade>();
		trades.add(trade1);
		trades.add(trade2);
		eventB.setTrades(trades);*/
		
		Calendar ls1 = Calendar.getInstance();
		
		Calendar ls2 = Calendar.getInstance();
		
		ls2.add(Calendar.MINUTE, 3);
		
		Date tradeDateTime1 = ls1.getTime();
		Date tradeDateTime2 = ls2.getTime();
		
		eventA.setOriginal_execution_date_time(tradeDateTime1);
		eventB.setCreatedOn(tradeDateTime2);
		
		//SessionPseudoClock clock = kieSession.getSessionClock();

		
		
		System.err.println("time 1 : " + tradeDateTime1);
		System.err.println("time 2 : " + tradeDateTime2);
		long v1 = tradeDateTime1.getTime() ;
		long v2 = tradeDateTime2.getTime();
		System.err.println("time dif sec : " +  TimeUnit.MILLISECONDS.toSeconds(v2-v1));
		System.err.println("time dif  min " + TimeUnit.MILLISECONDS.toMinutes(v2-v1));
		
		
		
		kieSession.insert(eventA);
		kieSession.insert(eventB);
		kieSession.fireAllRules();
		
		logger.close();
	
	
	/*try {
	Thread.sleep(3000);
		} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
	*/
	}
	

}
