package com.cibc.event;
@org.kie.api.definition.type.Role(org.kie.api.definition.type.Role.Type.EVENT)
//@org.kie.api.definition.type.Expires("10s")
public class Trade {
	 private String sourceSystemTradeID;
     private String globeMessageID;
    
     public String getSourceSystemTradeID() {
            return sourceSystemTradeID;
     }
     public void setSourceSystemTradeID(String sourceSystemTradeID) {
            this.sourceSystemTradeID = sourceSystemTradeID;
     }
     public String getGlobeMessageID() {
            return globeMessageID;
     }
     public void setGlobeMessageID(String globeMessageID) {
            this.globeMessageID = globeMessageID;
     }
     @Override
     public String toString() {
            return "Trade [sourceSystemTradeID=" + sourceSystemTradeID + ", globeMessageID=" + globeMessageID + "]";
     }
}
