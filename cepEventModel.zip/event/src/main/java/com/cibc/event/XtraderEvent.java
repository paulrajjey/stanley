package com.cibc.event;

import java.util.Date;


@org.kie.api.definition.type.Role(org.kie.api.definition.type.Role.Type.EVENT)
//@org.kie.api.definition.type.Expires("10s")
@org.kie.api.definition.type.Timestamp("original_execution_date_time")
public class XtraderEvent {
	 private Date original_execution_date_time;
     
     private String usi_trans_id;
    
     private String struct_ref;
     private String hold_id;
    
     public Date getOriginal_execution_date_time() {
            return original_execution_date_time;
     }
     public void setOriginal_execution_date_time(Date original_execution_date_time) {
            this.original_execution_date_time = original_execution_date_time;
     }
     public String getUsi_trans_id() {
            return usi_trans_id;
     }
     public void setUsi_trans_id(String usi_trans_id) {
            this.usi_trans_id = usi_trans_id;
     }
     public String getStruct_ref() {
            return struct_ref;
     }
     public void setStruct_ref(String struct_ref) {
            this.struct_ref = struct_ref;
     }
     public String getHold_id() {
            return hold_id;
     }
     public void setHold_id(String hold_id) {
            this.hold_id = hold_id;
     }
}
