package com.cibc.event;

import java.util.Date;
import java.util.List;
@org.kie.api.definition.type.Role(org.kie.api.definition.type.Role.Type.EVENT)
//@org.kie.api.definition.type.Expires("10s")
@org.kie.api.definition.type.Timestamp("createdOn")
public class GlobalServiceEvent {

	private String globeMessageID;
    private String SourceSystemTransID;
    private String PartyAUsiTransid;
    private Date  createdOn;
    private List<Trade> trades ;
   
    public String getGlobeMessageID() {
           return globeMessageID;
    }
    public void setGlobeMessageID(String globeMessageID) {
           this.globeMessageID = globeMessageID;
    }
    public String getSourceSystemTransID() {
           return SourceSystemTransID;
    }
    public void setSourceSystemTransID(String sourceSystemTransID) {
           SourceSystemTransID = sourceSystemTransID;
    }
    public String getPartyAUsiTransid() {
           return PartyAUsiTransid;
    }
    public void setPartyAUsiTransid(String partyAUsiTransid) {
           PartyAUsiTransid = partyAUsiTransid;
    }
    
    public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public List<Trade> getTrades() {
           return trades;
    }
    public void setTrades(List<Trade> trades) {
           this.trades = trades;
    }
    
}
